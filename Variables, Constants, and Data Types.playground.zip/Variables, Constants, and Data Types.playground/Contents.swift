import UIKit

var myAge : Int = 25

myAge = 26

let myName : String = "Joe"

let myAgeInTenYears = myAge + 10

let myDetails = "\(myName), \(myAge)"

let wholeNumbers : Int = 12
let text : String = "abc"

let booleans : Bool = true
let floatingPointNumber : Float = 1.4
let double : Double = 64.2475378034
